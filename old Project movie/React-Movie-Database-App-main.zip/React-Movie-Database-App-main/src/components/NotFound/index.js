const NotFound = () => (
  <div>
    <h1>Not found</h1>
  </div>
)

export default NotFound
